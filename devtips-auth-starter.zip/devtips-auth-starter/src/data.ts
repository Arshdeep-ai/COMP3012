import type { TTip } from "./types";
import { randomUUID } from "crypto";

type TUser = { id: string; username: string; password: string; tips: TTip[] };

let database: TUser[] = [
  {
    id: "A0328Xhf8",
    username: "jimmy123",
    password: "jimmy123!",
    tips: [
      {
        id: "1",
        text: "Prefer const over let when you can.",
        likes: 2,
        createdAt: Date.now() - 10000,
      },
    ],
  },
  {
    id: "BFGZ8328X",
    username: "sandra123",
    password: "sandra123!",
    tips: [
      {
        id: "2",
        text: "Name things clearly, future you will thank you.",
        likes: 5,
        createdAt: Date.now() - 5000,
      },
    ],
  },
];

// TODO: Add a userId field and modify inner logic to use it
export function getTips(userId: string) {
  const user = database.find((u) => u.id === userId);
  return user?.tips || [];
}

// TODO: Add a userId field and modify inner logic to use it
export function addTip(userId: string, text: string) {
  const user = database.find((u) => u.id === userId);
  if (!user) return;

  const tip: TTip = {
    id: randomUUID(),
    text,
    likes: 0,
    createdAt: Date.now(),
  };

  user.tips.push(tip);
  return tip;
}

// TODO: Add a userId field and modify inner logic to use it
export function like(userId: string, id: string) {
  const user = database.find((u) => u.id === userId);
  const foundTip = user?.tips.find((tip) => tip.id === id);
  if (foundTip) {
    foundTip.likes++;
  }
  return foundTip;
}

// TODO: Add a userId field and modify inner logic to use it
export function dislike(userId: string, id: string) {
  const user = database.find((u) => u.id === userId);
  const foundTip = user?.tips.find((tip) => tip.id === id);
  if (foundTip) {
    foundTip.likes--;
  }
  return foundTip;
}

// TODO: Add a userId field and modify inner logic to use it
export function remove(userId: string, id: string) {
  const user = database.find((u) => u.id === userId);
  const tipIndex = user?.tips.findIndex((tip) => tip.id === id);
  if (tipIndex !== undefined && tipIndex !== -1) {
    user?.tips.splice(tipIndex, 1);
  }
}

export function findUser(username: string, password: string) {
  return database.find(
    (user) => user.username === username && user.password === password
  );
}
