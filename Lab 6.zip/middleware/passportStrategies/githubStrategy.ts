import { Strategy as GitHubStrategy } from 'passport-github2';
import { PassportStrategy } from '../../interfaces/index';
import { Request } from 'express';
import { Profile } from 'passport-github2';

const githubStrategy: GitHubStrategy = new GitHubStrategy(
    {
        clientID: process.env.GITHUB_CLIENT_ID!,
        clientSecret: process.env.GITHUB_CLIENT_SECRET!,
        callbackURL: process.env.GITHUB_CALLBACK_URL!,
        passReqToCallback: true,
    },
    
    /* FIX ME 😭 */
    async (
        req: Request,
        accessToken: string,
        refreshToken: string,
        profile: Profile,
        done: (err: any, user?: any) => void
        ) => {
        try {
      const user = {
        id: profile.id,
        name: profile.displayName || profile.username,
        email: profile.emails?.[0]?.value || 'No public email',
      };

      if (!(global as any).githubUserCache) (global as any).githubUserCache = {};
      (global as any).githubUserCache[user.id] = user;

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }
);

const passportGitHubStrategy: PassportStrategy = {
    name: 'github',
    strategy: githubStrategy,
};

export default passportGitHubStrategy;
