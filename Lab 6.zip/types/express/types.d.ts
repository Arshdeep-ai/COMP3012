import { User as MyUser } from "../../models/userModel";

declare global {
  namespace Express {
    interface User extends import("../../models/userModel").User {}
  }
}

