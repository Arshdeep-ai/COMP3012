import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { getUserByEmailIdAndPassword, getUserById} from "../../controllers/userController";
import { PassportStrategy } from '../../interfaces/index';

const localStrategy = new LocalStrategy(
  {
    usernameField: "email",
    passwordField: "password",
  },
  (email, password, done) => {
    const user = getUserByEmailIdAndPassword(email, password);
    return user
      ? done(null, user)
      : done(null, false, {
          message: "Your login details are not valid. Please try again",
        });
  }
);

/*
FIX ME (types) 😭
*/
passport.serializeUser((user: any, done) => {
  const id = (user as { id: number }).id;
  done(null, id);
});


/*
FIX ME (types) 😭
*/
passport.deserializeUser((id: number, done) => {
  const user = getUserById(id);
  if (user) return done(null, user);

  // Fallback for GitHub users
  const githubUser = (global as any).githubUserCache?.[id];
  if (githubUser) return done(null, githubUser);

  return done(new Error("User not found"));
});

const passportLocalStrategy: PassportStrategy = {
  name: 'local',
  strategy: localStrategy,
};

export default passportLocalStrategy;
