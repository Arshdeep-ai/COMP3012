import express, { Request, Response } from "express";
import { ensureAdmin } from "../middleware/checkAdmin";

const router = express.Router();

// Admin dashboard: list all sessions
router.get("/", ensureAdmin, (req: Request, res: Response) => {
    const store = req.sessionStore;
    if (!store) return res.send("No session store found");

    (store as any).all((err: any, sessions: Record<string, any> | null) => {
        if (err) {
            return res.send("Error retrieving sessions");
        }

        const sessionList = Object.entries(sessions ?? {}).map(([sid, sess]: [string, any]) => ({
            sid,
            userId: sess.passport?.user || "unknown",
        }));

        res.render("admin", { sessions: sessionList, user: req.user });
    });
});

// Revoke a session
router.post("/revoke/:sid", ensureAdmin, (req: Request, res: Response) => {
    const store = req.sessionStore;
    if (!store) return res.send("No session store found");

    store.destroy(req.params.sid, (err) => {
        if (err) console.error(err);
        res.redirect("/admin");
    });
});

export default router;
