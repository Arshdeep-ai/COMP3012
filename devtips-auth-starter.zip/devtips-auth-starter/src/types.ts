export type TTip = {
  id: string;
  text: string;
  likes: number;
  createdAt: number;
};
