import express from "express";
import path from "node:path";
import morgan from "morgan";
import session from "express-session";
import { findUser } from "./data";
import { addTip, dislike, getTips, like, remove } from "./data";

const app = express();
const PORT = 3001;

app.set("view engine", "ejs");

app.use(morgan("dev"));

app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

app.use(
  session({
    secret: "devtips-secret",
    resave: false,
    saveUninitialized: false,
  })
);

app.get("/", (req, res) => {
  // TODO: 1) Add a conditional check to see if a user has a session & is logged in. If not, redirect to /login.
  //       2) If they do have a session, get their id from the session and use it to lookup their tips.
  //          You will probably want to modify the getTips function so it takes in a userId and returns the tips for that user
  if (!req.session.userId) {
    return res.redirect("/login");
  }
  const tips = getTips(req.session.userId);
  res.render("index", { tips });
});

app.get("/login", (req, res) => {
  // TODO: Replace this with an html form that has:
  //       1) An Email input
  //       2) A  Password input
  //       3) A Login Button
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Login</title>
      </head>
      <body>
        <h1>Login</h1>
        <form method="POST" action="/login">
          <label>
            Username:
            <input type="text" name="username" required />
          </label>
          <br><br>
          <label>
            Password:
            <input type="password" name="password" required />
          </label>
          <br><br>
          <button type="submit">Login</button>
        </form>
      </body>
    </html>
  `);
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  // TODO: 1) Check the database to see if you find a matching username + password
  //       2) If you find a match, create a session and redirect them to /tips
  //       3) If you do NOT find a match, redirect them to /login
  const user = findUser(username, password);

  if (user) {
    req.session.userId = user.id;
    res.redirect("/");
  } else {
    res.redirect("/login");
  }
});

app.post("/tips", (req, res) => {
  const { text } = req.body;
  if (text) {
    addTip(req.session.userId!, text);
  }
  res.redirect("/");
});

app.post("/tips/:id/like", (req, res) => {
  const id = req.params.id;
  const likedTip = like(req.session.userId!, id);
  res.redirect("/");
});

app.post("/tips/:id/dislike", (req, res) => {
  const id = req.params.id;
  const dislikedTip = dislike(req.session.userId!, id);
  res.redirect("/");
});

app.post("/tips/:id/delete", (req, res) => {
  const id = req.params.id;
  remove(req.session.userId!, id);
  res.redirect("/");
});

app.listen(PORT, () => {
  console.log(`
🚀 http://localhost:${PORT}`);
});
